<?php 
	require_once 'incs/header.php';
?>
<div class="container-fluid">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 pull-right">
				<figure><img src="assets/images/banner.png" alt="" class="img-responsive"></figure>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				<div class="welcome-block">
					<h1>Contact <span>Us</span></h1>
					<p>address goes here..</p>
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
	require_once 'incs/footer.php';
?>