-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 19, 2016 at 12:31 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo-sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `person_contact`
--

CREATE TABLE `person_contact` (
  `per_id` int(11) NOT NULL,
  `per_name` varchar(100) DEFAULT NULL,
  `per_mobile` bigint(20) DEFAULT NULL,
  `per_grid` varchar(100) DEFAULT NULL,
  `per_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person_contact`
--

INSERT INTO `person_contact` (`per_id`, `per_name`, `per_mobile`, `per_grid`, `per_time`) VALUES
(1, 'Samar Kumar', 9175548955, '1', '2016-06-17 09:42:29'),
(2, 'Mahaveer Singh Chauhan', 9920064505, '3', '2016-06-17 09:43:03'),
(3, 'Paramveer Singh Chauhan', 9920064502, '3', '2016-06-17 09:43:35');

-- --------------------------------------------------------

--
-- Table structure for table `sms_category`
--

CREATE TABLE `sms_category` (
  `ca_id` int(11) NOT NULL,
  `ca_name` varchar(100) DEFAULT NULL,
  `ca_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sms_category`
--

INSERT INTO `sms_category` (`ca_id`, `ca_name`, `ca_time`) VALUES
(1, 'Jockes', '2016-02-17 17:51:28'),
(2, 'Birthday', '2016-02-17 17:56:46'),
(3, 'Anniversary', '2016-02-17 17:58:17'),
(4, 'Good Morning', '2016-02-17 18:15:21'),
(5, 'Good Night', '2016-02-20 04:54:41'),
(6, 'Good Evening', '2016-03-12 10:33:43'),
(7, 'Independence Day', '2016-06-17 04:53:22');

-- --------------------------------------------------------

--
-- Table structure for table `sms_group`
--

CREATE TABLE `sms_group` (
  `gr_id` int(11) NOT NULL,
  `gr_name` varchar(100) DEFAULT NULL,
  `gr_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sms_group`
--

INSERT INTO `sms_group` (`gr_id`, `gr_name`, `gr_time`) VALUES
(1, 'Collage', '2016-06-17 09:27:24'),
(2, 'Family', '2016-06-17 09:27:29'),
(3, 'Office', '2016-06-17 09:27:34'),
(4, 'Best group', '2016-06-17 09:27:42');

-- --------------------------------------------------------

--
-- Table structure for table `sms_login`
--

CREATE TABLE `sms_login` (
  `log_id` int(11) NOT NULL,
  `log_name` varchar(100) DEFAULT NULL,
  `log_email` varchar(100) DEFAULT NULL,
  `log_mobile` bigint(20) DEFAULT NULL,
  `log_pass` varchar(100) DEFAULT NULL,
  `log_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sms_login`
--

INSERT INTO `sms_login` (`log_id`, `log_name`, `log_email`, `log_mobile`, `log_pass`, `log_time`) VALUES
(1, 'Hello', 'hello@gmail.co.in', 1234567890, '7fed26a674b31129e33c73b0dd37668a44a7e625', '2016-02-15 12:07:51'),
(2, 'Sarvesh Kumar Prajapati', 'sarvesh@gmail.com', 9175548955, '5e643324fe2c7b982dca31b9eebe152e31c71c43', '2016-04-09 17:02:36'),
(3, 'Prahlad Prajapati', 'prahlad@gmail.com', 1234567890, '5e643324fe2c7b982dca31b9eebe152e31c71c43', '2016-03-26 11:30:56');

-- --------------------------------------------------------

--
-- Table structure for table `sms_message`
--

CREATE TABLE `sms_message` (
  `sms_id` int(11) NOT NULL,
  `sms_msg` varchar(100) DEFAULT NULL,
  `sms_caid` int(11) DEFAULT NULL,
  `sms_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sms_message`
--

INSERT INTO `sms_message` (`sms_id`, `sms_msg`, `sms_caid`, `sms_time`) VALUES
(2, 'Happy Birthday 2 u', 2, '2016-06-17 09:15:13'),
(3, 'Good Morning.', 4, '2016-06-17 09:15:40'),
(4, 'Sweet Dream', 5, '2016-06-17 09:16:17'),
(5, 'Good Night.', 5, '2016-06-17 09:20:44'),
(6, 'Sweet Good morning.', 4, '2016-06-17 09:21:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `person_contact`
--
ALTER TABLE `person_contact`
  ADD PRIMARY KEY (`per_id`);

--
-- Indexes for table `sms_category`
--
ALTER TABLE `sms_category`
  ADD PRIMARY KEY (`ca_id`);

--
-- Indexes for table `sms_group`
--
ALTER TABLE `sms_group`
  ADD PRIMARY KEY (`gr_id`);

--
-- Indexes for table `sms_login`
--
ALTER TABLE `sms_login`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `sms_message`
--
ALTER TABLE `sms_message`
  ADD PRIMARY KEY (`sms_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `person_contact`
--
ALTER TABLE `person_contact`
  MODIFY `per_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sms_category`
--
ALTER TABLE `sms_category`
  MODIFY `ca_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `sms_group`
--
ALTER TABLE `sms_group`
  MODIFY `gr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `sms_login`
--
ALTER TABLE `sms_login`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sms_message`
--
ALTER TABLE `sms_message`
  MODIFY `sms_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
